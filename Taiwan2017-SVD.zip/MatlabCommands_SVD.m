clear
close all
clc

%%  Define matrices
X = [ 1 -1 
      0  1 
      1  0 ]
% or simply X = [1,-1; 0, 1; 1, 0];

%% generate a random matrix whose entries are iid Uniform(0,1)
Y = rand(100,100)

%% Singular value decomposition

% help svd

[U,S,V] = svd(X) % full SVD

[U,S,V] = svd(X, 'econ') % economic SVD 

s = svd(X)  % only the vector of singular values

s = svds(Y,10) % find only a few singular values
[U,S,V] = svds(Y,5) % find only a few singular values and singular vectors

%% matrix norms
% help norm

X_Fnorm = norm(X,'fro') % Frobenius norm
X_2norm = norm(X,2) % 2-norm, or spectral norm

% Note that the matrix nuclear norm is not implemented in MATLAB.
% You can use the following lines to do it.
X_Nuclear_norm = sum(svd(X))

%% low rank approximation
k = 2;
X_k = U(:,1:k)*S(1:k,1:k)*V(:,1:k)'

%% Image compression
A = imread('cr.bmp');
figure; imshow(A);

A = double(A);
kmax = 30;
[U,S,V]=svds(A,kmax);
I = zeros([size(A) kmax]);
for k = 1:kmax
    I(:,:,k)= U(:,1:k)*S(1:k,1:k)*V(:,1:k)';
end

figure; DisplayImageCollection(I);

%% orthogonal least squares fitting

load OLS_toydata
X(end+1, :) = [1.5*max(X(:,1)) mean(X(:,2))]; %add an outlier

figure; 
plot(X(:,1), X(:,2), 'b.', 'MarkerSize', 14)
axis equal
%xlim([0 1.5])
%ylim([0 2])
hold on

n = size(X,1);
center = mean(X,1); % average of the data
%center = zeros(1,2); % put center at origin
X_tilde = X - repmat(center, n, 1); % centered data

[U,S,V] = svd(X_tilde,'econ'); % svd

k = 1;
X_k = U(:,1:k)*S(1:k,1:k)*V(:,1:k)';  % rank k approximation to X_tilde
X_k = X_k + repmat(center, n, 1);

plot(X_k(:,1), X_k(:,2), 'r-', 'linewidth', 2) % plot projection

%% solving redundant systems Ax =b
A = [1,-1; 0, 1; 1, 0]
b = [0 3 2]'

% The following methods are all equivalent
x_opt1 = pinv(A)*b

x_opt2 = A\b

[U,S,V] = svd(A,'econ');
x_opt3 = V*diag(1./diag(S))*U'*b % This is actually how MATLAB calculates matrix pseudoinverse

