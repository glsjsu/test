clear
close all
clc

%% load the MNIST handwritten digits data

load ../Data/MNIST_data_train % the whole training set
load ../Data/MNIST_data_test % the whole training set

X = [trainImages testImages];
labels = [trainLabels; testLabels];
m = 28;
n = 28;

I = reshape(X(:,randsample(size(X,2), 1000)), m, n,[]);
figure; DisplayImageCollection(I);

X = X'; % convert to 70000 x 784

X = X(labels==1,:); % use only the digit 1

%% load and display the extended Yable B face images (frontal pose only)
load ../Data/extendedYaleB_crop

m = 192;
n = 168;
X =  matI(:,labels<6);
figure; DisplayImageCollection(reshape(X,m,n,[]));

X = X';
labels = labels(labels<6);

%% PCA

[N,d] = size(X); % d = m*n
ave = mean(X,1); % average face
figure; imagesc(reshape(ave,m,n)); colormap gray;

X_c = X-repmat(ave,N,1);
[U,S,V] = svds(X_c,50);

s = diag(S);
figure; plot(s, 'b.', 'MarkerSize', 12); title('Singular values'); grid on

figure; plot(cumsum(s.^2)/norm(X_c,'fro')^2, 'b.', 'MarkerSize', 12); title('Explained variance'); grid on

figure; DisplayImageCollection(reshape(V,m,n,[])); title 'basis'

figure; plot(S(1,1)*U(:,1), S(2,2)*U(:,2), '.', 'MarkerSize', 12); title 'principle coordinates'

figure; plot3(S(1,1)*U(:,1), S(2,2)*U(:,2), S(3,3)*U(:,3), '.')

%figure; gcplot(U(:,1:3)*S(1:3,1:3), labels(labels<6))